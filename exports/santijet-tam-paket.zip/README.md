# ŞantiJET - Şantiye Takip Uygulaması

Türkçe inşaat şantiyesi yönetimi için Expo (React Native + Web) uygulaması.

## Kurulum

Gereksinimler: Node.js 20+, pnpm 9+

```bash
pnpm install
```

## Çalıştırma

### Web (geliştirme önizlemesi)
```bash
pnpm --filter @workspace/santiye-takip run dev:web
```
Tarayıcıda http://localhost:8081 (veya Expo'nun verdiği port).

### Mobil / Expo
```bash
pnpm --filter @workspace/santiye-takip run dev
```
Telefonda Expo Go ile QR kodu okutarak çalıştırabilirsiniz.

## Yapı

- `artifacts/santiye-takip/` — Ana Expo uygulaması (tüm ekranlar, context, bileşenler)
- `lib/api-client-react/` — Paylaşılan React Query hook'ları (opsiyonel)
- `lib/api-spec/`, `lib/api-zod/` — OpenAPI sözleşmesi ve Zod şemaları
- `scripts/` — Yardımcı geliştirme betikleri

## Önemli Modüller

- **Satın Alma** (`/satin-alma`) — Sipariş yönetimi, KasaFON köprüsü
- **Malzeme** (`/malzeme`) — Talep onayları otomatik Satın Alma kaydı oluşturur
- **Finans / KasaFON** (`/finans`) — Gömülü bütçe takip uygulaması
- 30+ diğer modül: Proje, Keşif, Puantaj, Bütçe, Hakediş, vb.

## Veri Saklama

Tüm veri AsyncStorage'da yerel olarak tutulur. KasaFON ve ŞantiJET aynı AsyncStorage instance'ını paylaşır — Satın Alma "Ödendi" yapıldığında otomatik olarak KasaFON'a gider hareketi yazılır.

## Notlar

- Bu paket pnpm workspace yapısındadır; mutlaka `pnpm` kullanın (`npm` veya `yarn` çalışmaz).
- `pnpm-workspace.yaml` santiye-takip için minimuma indirgenmiştir.
